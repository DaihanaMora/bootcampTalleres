module ClinicsHelper
end
